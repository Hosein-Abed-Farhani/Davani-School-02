<html lang="en" dir="rtl">

<head>
    <meta charset="UTF-8">
    <!-- محدود کردن زوم با دو انگشت در گوشی -->
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, shrink-to-fit=no">
    <title>هنرستان علامه دوانی - پروفایل کاربر</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="all.css">
    <link rel="stylesheet" href="article.css">
    <link rel="icon" href="images/favicon.png">
</head>

<body>

    <!-- header & scroll bar & navbar start -->

    <?php
    include("header.php")
        ?>

    <!-- header & scroll bar & navbar start  -->

    <!-- content start -->

    <h1 style="margin-top: 300px;width: 100%;text-align: center;font-size: 30px;margin-bottom:300px;">به زودی....</h1>

    <!-- content end -->

    <!-- float btn (back to top) & footer start -->

    <?php
    include("footer.php")
        ?>

    <!-- float btn (back to top) & footer end -->

    <!-- scripts start -->

    <script src="scripts/all.js"></script>
    <script src="scripts/article.js"></script>

    <!-- scripts end -->
</body>

</html>